import React from 'react';

function Home() {
  return (
    <div className="p-10 text-center">
      <h1 className="text-4xl font-bold">Compare UAE Vehicle Insurance</h1>
      <p className="mt-4">Enter your car details and find the best insurance quotes for free.</p>
      <button className="mt-6 px-4 py-2 bg-blue-600 text-white rounded">Start Comparing</button>
    </div>
  );
}

export default Home;